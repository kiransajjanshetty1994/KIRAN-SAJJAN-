DR. KIRAN SAJJANSHETTY — ACADEMIC WEBSITE

Files:
- index.html: Complete responsive one-page academic website.
- profile-photo.webp: Profile photograph used on the homepage.

FREE PUBLISHING OPTION (GitHub Pages):
1. Sign in to https://github.com/ or create a free account.
2. Create a new public repository named: kiran-sajjanshetty.github.io
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, select Deploy from a branch, choose main and /(root), then Save.
6. GitHub will publish the site at https://kiran-sajjanshetty.github.io/

You may instead use Google Sites at https://sites.google.com/ to create a no-code site.
This HTML file is a standalone website and is not automatically published to your Google account.

CONTENT CHECK BEFORE PUBLICATION:
- Verify the listed publication titles, journal details, DOI links and reviewer counts.
- Confirm Ph.D. institution/year and postdoctoral institution, research area and dates.
- Add a professional photograph if desired.
- Add an institutional email and official contact details only if you want them public.
- Update the selected publications from your latest CV/Google Scholar record.

The site uses no paid services, external libraries, analytics or tracking scripts.
